# CameraDemo
一个较为完整的相机Demo
##基于Camera2 API
![demo截图](http://upload-images.jianshu.io/upload_images/4774781-0f8828373d8b1079.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

##V1.0 主要功能
- 前置、后置摄像头一件切换
- 保存图片
- 闪光灯的控制


本demo是基于这篇博客改的：[Android Camera2 拍照入门学习](http://www.jianshu.com/p/7f766eb2f4e7) 感谢大神。

package com.baidu.aip.asrwakeup3.mini;

import com.baidu.aip.asrwakeup3.core.mini.ActivityMiniUnit;

public class ActivityMyMiniUnit extends ActivityMiniUnit {

}

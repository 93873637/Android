package com.baidu.aip.asrwakeup3.mini;

import com.baidu.aip.asrwakeup3.core.mini.ActivityMiniWakeUp;

public class ActivityMyMiniWakeUp extends ActivityMiniWakeUp {
}

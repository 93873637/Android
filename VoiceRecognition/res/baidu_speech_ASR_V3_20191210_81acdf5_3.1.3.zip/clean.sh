#!/bin/sh
rm -rf output *.zip  build/* app/build/* core/build/* uiasr/build/* uidialog/build/* .gradle
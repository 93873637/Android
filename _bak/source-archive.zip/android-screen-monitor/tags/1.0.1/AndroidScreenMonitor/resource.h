//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AndroidScreenMonitor.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ANDROIDSCREENMONITOR_DIALOG 102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDD_ADBC                        129
#define IDR_MAINFRAME                   131
#define IDD_SELECT_DEVICE               139
#define IDC_BUTTON_START                1000
#define IDC_BUTTON_TERMINATE            1001
#define IDC_BUTTON_RESTART              1002
#define IDC_LIST_DEVICE                 1100
#define IDC_BUTTON_REFRESH              1101
#define IDC_BUTTON_ACCESS               1103

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1104
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

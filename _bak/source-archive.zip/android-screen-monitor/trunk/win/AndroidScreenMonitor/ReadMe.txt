The Android Screen Monitor (ASM) is a tool to monitor screen on the device or emulator.

ASM is an Android Debug Bridge (adb) client, When it starts monitoring screen,
ASM connects to adb on port 5037 and recieves continuously frame buffer on the device or emulator.

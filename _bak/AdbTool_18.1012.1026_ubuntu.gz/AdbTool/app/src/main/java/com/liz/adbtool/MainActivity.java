package com.liz.adbtool;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.liz.adbtool.utils.LogUtils;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText mCmdTerminal;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mCmdTerminal = findViewById(R.id.cmdTerminal);

        EditText editSearch = findViewById(R.id.editSearch);
        editSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    onSearch();
                }
                return true;
            }
        });

        /*
        //replaced by LinearLayout Terminal onClick
        ScrollView svTerminal = findViewById(R.id.sv_Terminal);
        svTerminal.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                view.getParent().requestDisallowInterceptTouchEvent(true);
                switch (motionEvent.getAction()){
                    case MotionEvent.ACTION_UP:
                        mCmdTerminal.setFocusable(true);
                        mCmdTerminal.setFocusableInTouchMode(true);
                        mCmdTerminal.requestFocus();
                        InputMethodManager im = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                        im.showSoftInput(mCmdTerminal, 0);
                        break;
                }
                return false;
            }
        });
        //*/

        LinearLayout llTerminal = findViewById(R.id.ll_Terminal);
        llTerminal.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.ll_Terminal:
                mCmdTerminal.setFocusable(true);
                mCmdTerminal.setFocusableInTouchMode(true);
                mCmdTerminal.requestFocus();
                InputMethodManager im = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                if (im == null) {
                    LogUtils.e("get input method manager failed");
                }
                else {
                    im.showSoftInput(mCmdTerminal, 0);
                }
                break;
        }
    }

    protected void onSearch() {
        //String keyWords = mEditSearch.getText().toString();
        //TODO: search key words in text view
    }
}

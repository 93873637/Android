package com.liz.adbtool;

import android.content.Context;
import android.support.v7.widget.AppCompatEditText;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.util.AttributeSet;

import com.liz.adbtool.utils.LogUtils;

public class CmdTerminal extends AppCompatEditText implements TextWatcher {

    private final String CMD_PROMPT = "# ";

    private StringBuffer mCmdBuffer;
    private boolean mWaitingForCommand;  //whether we are waiting for cmd input or not

    public CmdTerminal(Context context) {
        this(context, null);
    }

    public CmdTerminal(Context context, AttributeSet attrs) {
        this(context, attrs, android.R.attr.editTextStyle);
    }

    public CmdTerminal(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

        mCmdBuffer = new StringBuffer();

        this.setText(CMD_PROMPT);
        mWaitingForCommand = true;

        this.setMovementMethod(ScrollingMovementMethod.getInstance());
        this.setSelection(this.getText().toString().length());
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        //LogUtils.d("beforeTextChanged");
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        //LogUtils.d("onTextChanged:" + s + "-" + "-" + start + "-" + "-" + before + "-" + count);
        onTextInput(s.subSequence(start, start + count));
    }

    @Override
    public void afterTextChanged(Editable s) {
        //LogUtils.d("afterTextChanged");
    }

    private void onTextInput(CharSequence inputChars) {
        if (!mWaitingForCommand) {
            LogUtils.d("onTextInput: not waiting for command, ignore input");
            return;
        }

        LogUtils.d("onTextInput: " + inputChars);
        for (int i=0; i<inputChars.length(); i++) {
            char c = inputChars.charAt(i);
            if (c == '\n') {
                LogUtils.d("onTextInput: get enter key");
                onCommand(mCmdBuffer.toString());
            }
            else {
                mCmdBuffer.append(c);
            }
        }
    }

    private void onCommand(String cmdStr) {
        LogUtils.d("onCommand: cmdStr=\"" + cmdStr + "\"");
        mWaitingForCommand = false;
        if (!TextUtils.isEmpty(cmdStr)) {
            //run command and show result
            String cmdResult =  CmdRunner.exec(mCmdBuffer.toString());
            if (TextUtils.isEmpty(cmdResult)) {
                LogUtils.d("empty result by command \"" + cmdStr + "\"");
            }
            else {
                append(cmdResult);
                append("\n");
            }
        }
        append(CMD_PROMPT);
        mWaitingForCommand = true;

        //clear cmd buffer
        int sbLen = mCmdBuffer.length();
        mCmdBuffer.delete(0, sbLen);
        mCmdBuffer = new StringBuffer();
    }
}

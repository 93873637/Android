package com.cry.cry.rtmp.rtmp;


public interface RESFlvDataCollecter {
    void collect(RESFlvData flvData, int type);
}

package com.cry.cry.mediaprojectioncode;

public interface SurfaceMaker {
    SurfaceFactory provide();

}

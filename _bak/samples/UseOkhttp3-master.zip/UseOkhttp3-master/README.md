# UseOkhttp3
Okhttp3简单使用和封装使用，代码根据自己项目需求修改即可使用。

## 效果图

![效果图.gif](https://upload-images.jianshu.io/upload_images/3735156-547bfd89af07de83.gif?imageMogr2/auto-orient/strip)

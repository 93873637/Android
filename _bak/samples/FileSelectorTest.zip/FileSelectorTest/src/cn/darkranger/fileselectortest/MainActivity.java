package cn.darkranger.fileselectortest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;
import dr.android.fileselector.FileSelectConstant;

public class MainActivity extends AppCompatActivity {
	private static final String TAG = "MainActivity";
	private static final Integer FILE_SELECTOR_REQUEST_CODE = 2016;

	private TextView mFileTv;
	private TextView mFileMultiTv;
	private TextView mFolderTv;
	private TextView mFolderMultiTv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initView();
		initData();
		initEvent();
	}

	private void initView() {
		mFileTv = (TextView) findViewById(R.id.id_mode_file);
		mFileMultiTv = (TextView) findViewById(R.id.id_mode_file_multi);
		mFolderTv = (TextView) findViewById(R.id.id_mode_folder);
		mFolderMultiTv = (TextView) findViewById(R.id.id_mode_folder_multi);
	}

	private void initData() {

	}

	private void initEvent() {
		// 文件单选
		mFileTv.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(getApplicationContext(), FsActivity.class);
				intent.putExtra(FileSelectConstant.SELECTOR_REQUEST_CODE_KEY, FileSelectConstant.SELECTOR_MODE_FILE);
				startActivityForResult(intent, FILE_SELECTOR_REQUEST_CODE);
			}
		});
		// 文件多选
		mFileMultiTv.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(getApplicationContext(), FsActivity.class);
				intent.putExtra(FileSelectConstant.SELECTOR_REQUEST_CODE_KEY, FileSelectConstant.SELECTOR_MODE_FILE);
				intent.putExtra(FileSelectConstant.SELECTOR_IS_MULTIPLE, true);
				startActivityForResult(intent, FILE_SELECTOR_REQUEST_CODE);
			}
		});

		// 文件夹单选
		mFolderTv.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(getApplicationContext(), FsActivity.class);
				intent.putExtra(FileSelectConstant.SELECTOR_REQUEST_CODE_KEY, FileSelectConstant.SELECTOR_MODE_FOLDER);
				startActivityForResult(intent, FILE_SELECTOR_REQUEST_CODE);
			}
		});

		// 文件夹多选
		mFolderMultiTv.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(getApplicationContext(), FsActivity.class);
				intent.putExtra(FileSelectConstant.SELECTOR_REQUEST_CODE_KEY, FileSelectConstant.SELECTOR_MODE_FOLDER);
				intent.putExtra(FileSelectConstant.SELECTOR_IS_MULTIPLE, true);
				startActivityForResult(intent, FILE_SELECTOR_REQUEST_CODE);
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent bundle) {
		super.onActivityResult(requestCode, resultCode, bundle);
		Log.i(TAG, "requestCode: " + requestCode + "; resultCode: " + resultCode);
		if (resultCode == RESULT_OK) {
			Toast.makeText(this, "paths: " + bundle.getStringArrayListExtra(FileSelectConstant.SELECTOR_BUNDLE_PATHS),
					Toast.LENGTH_SHORT).show();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}

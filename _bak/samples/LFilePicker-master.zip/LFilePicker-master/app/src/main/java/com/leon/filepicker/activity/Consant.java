package com.leon.filepicker.activity;

/**
 * 作者：Leon
 * 时间：2017/3/23 14:51
 */
public class Consant {
    public static int REQUESTCODE_FROM_ACTIVITY = 1000;
    public static int REQUESTCODE_FROM_FRAGMENT = 1001;

}

package com.example.learn_opentok_android;

/**
 * Created by quanhua on 14/10/2015.
 */
public class ApiConfig {
    public static String mSessionID = MyApiConfig.mSessionID;
    public static String mToken = MyApiConfig.mToken;
    public static String mApiKey = MyApiConfig.mApiKey;
}

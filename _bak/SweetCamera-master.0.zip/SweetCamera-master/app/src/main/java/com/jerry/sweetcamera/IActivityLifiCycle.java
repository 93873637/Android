package com.jerry.sweetcamera;

/**
 * @author jerry
 * @date 2015-09-25
 */
public interface IActivityLifiCycle {
    void onStart();
    void onStop();
}

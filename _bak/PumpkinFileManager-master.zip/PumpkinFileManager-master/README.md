<h1>PumpkinFileManager</h1>
> <h3>南瓜文件管理器1.0.</h3></br>
> 功能列表：</br>
> 1: 实现了在ListView中浏览本地所有文件.</br>
> 2: 实现了对文件的增(新建文件夹)</br>
> 3: 删(删除文件或文件夹).</br>
> 4: 改(重命名以及复制粘贴文件).</br>
> 5: 查(对当前路径下的递归查询).</br>
> 6: 排(对显示在listView中的文件按时间，大小或文件名排序).</br>

> <h3> Pumpkin file manager 1.0.</h3></br>
> Function list: </br>
> 1: Implementation of browsing local all files in ListView.</br>
> 2: Implementation of the file to the.</br>
> 3: delete (delete files or folders).</br>
> 4: Change (rename and copy and paste files).</br>
> 5: Search (for the current path of recursive query).</br>
> 6: row (on display in listView file by time, size or file name).</br>

package net.yunstudio.demo;

import java.io.File;

import net.yunstudio.demo.FilePickerDialog.OnFileSelectListener;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {

	private TextView tv_path;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		tv_path=(TextView) findViewById(R.id.tv_path);
	}
	
	
	public void chooseFile(View view) {
		FilePickerDialog filePickerDialog=new FilePickerDialog(this);
		filePickerDialog.setOnFileSelectListener(new OnFileSelectListener() {
			@Override
			public void onFileSelect(File file) {
				tv_path.setText(file.getPath());
			}
		});
		filePickerDialog.show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
